package br.com.season.java8_lab01b;

import java.io.IOException;

/**
 * You can use filters to filter out sub-directories and print only file names, if you need it.
 *
 * @author emeloda
 *
 */
public class ListOnlyFilesInsideDirectory
{
	public static void main(String[] args) throws IOException
	{
		// code here

		System.out.println(" ");
		System.out.println("-----Using walk -----");
		System.out.println(" ");

		// code here
	}
}
