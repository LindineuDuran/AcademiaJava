package br.com.season.java8_lab06;

public class App {

	public static void LocalDateTimeApi() {

		// the current date

		System.out.println("the current date is " + date);

		// the current time

		System.out.println("the current time is " + time);

		// will give us the current time and date

		System.out.println("current date and time : " + current);

		// to print in a particular format


		System.out.println("in foramatted manner " + formatedDateTime);

		// printing months days and seconds

		System.out.println("Month : " + month + " day : " + day + " seconds : " + seconds);

		// printing some specified date

		System.out.println("the repulic day :" + date2);

		// printing date with current time.

		System.out.println("specfic date with " + "current time : " + specificDate);
	}

	// Driver code
	public static void main(String[] args) {
		LocalDateTimeApi();
	}
}
