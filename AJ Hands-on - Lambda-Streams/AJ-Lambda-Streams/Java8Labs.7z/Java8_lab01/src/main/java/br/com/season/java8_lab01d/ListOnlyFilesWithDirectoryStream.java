package br.com.season.java8_lab01d;

import java.io.IOException;

/**
 * List only files with Files.newDirectoryStream()
 *
 * @author Daniel Melo
 *
 */
public class ListOnlyFilesWithDirectoryStream
{
	public static void main(String[] args) throws IOException
	{
		// code here

	}
}
