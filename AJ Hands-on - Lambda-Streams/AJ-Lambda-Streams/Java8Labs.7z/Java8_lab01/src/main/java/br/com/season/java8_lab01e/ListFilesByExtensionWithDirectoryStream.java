package br.com.season.java8_lab01e;

import java.io.IOException;

/**
 * List files of certain extention with Files.newDirectoryStream().
 *
 * @author Daniel Melo
 *
 */
public class ListFilesByExtensionWithDirectoryStream
{
	public static void main(String[] args) throws IOException
	{
		// code here
	}
}
