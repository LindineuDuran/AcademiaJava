package br.com.season.methodreferences;

import java.util.Comparator;

import br.com.season.interfacesfuncionais.Pessoa;

public class ComparadorPessoas implements Comparator<Pessoa> {

	@Override
	public int compare(Pessoa o1, Pessoa o2) {
		return 0;
	}

}
