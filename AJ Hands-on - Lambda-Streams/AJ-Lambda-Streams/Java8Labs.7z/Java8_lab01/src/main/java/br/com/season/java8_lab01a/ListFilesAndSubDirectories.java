package br.com.season.java8_lab01a;

/**
 * Use Files.list() and Files.walk() methods to list all file names and
 * sub-directories in current directory.
 *
 * @author emeloda
 *
 */
public class ListFilesAndSubDirectories
{
	public static void main( String[] args )
	{
		// code here

		System.out.println(" ");
		System.out.println("-----Using walk -----");
		System.out.println(" ");

		// code here
	}
}
